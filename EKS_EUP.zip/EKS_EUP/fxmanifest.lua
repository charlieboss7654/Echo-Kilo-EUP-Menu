fx_version 'cerulean'
game 'gta5'

name 'EKS EUP Menu'
author 'R.Robertson - Echo Kilo Studios'
description 'EKS EUP Menu'
version '1.0.0'

ui_page 'ui/index.html'

files {
  'ui/index.html',
  'ui/style.css',
  'ui/script.js'
}

shared_scripts {
  'shared/config.lua'
}

client_scripts {
  'client/client.lua'
}

lua54 'yes'
