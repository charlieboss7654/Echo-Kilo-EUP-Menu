let SNAPSHOT = null;
let selectedOrg = -1;
let selectedCat = -1;

const root       = () => document.getElementById('eup-root');
const orgList    = () => document.getElementById('org-list');
const catList    = () => document.getElementById('cat-list');
const outfitGrid = () => document.getElementById('outfit-grid');
const orgTitle   = () => document.getElementById('org-title');
const catTitle   = () => document.getElementById('cat-title');
const searchBox  = () => document.getElementById('search');

const RES_NAME = (typeof GetParentResourceName === 'function')
  ? GetParentResourceName()
  : 'eks_eup_ui';

function nukeUI() {
  const el = root();
  if (el) el.classList.add('hidden');
}

function post(action, data) {
  if (action === 'close') nukeUI(); // hide immediately so user is never stuck
  fetch(`https://${RES_NAME}/${action}`, {
    method: 'POST',
    headers: { 'Content-Type':'application/json; charset=UTF-8' },
    body: JSON.stringify(data || {})
  }).catch(() => {});
}

function renderOrgs() {
  const ul = orgList(); if (!ul || !SNAPSHOT?.catalog) return;
  ul.innerHTML = '';
  SNAPSHOT.catalog.forEach((org, idx) => {
    const li = document.createElement('li');
    li.className = 'item';
    li.innerHTML = `<div class="label">${org.org}</div>`;
    li.addEventListener('click', () => {
      selectedOrg = idx; selectedCat = -1;
      if (orgTitle()) orgTitle().textContent = org.org;
      renderCats();
      const grid = outfitGrid(); if (grid) grid.innerHTML = '';
      if (catTitle()) catTitle().textContent = 'Select a category';
    });
    ul.appendChild(li);
  });
}

function renderCats() {
  const ul = catList(); if (!ul) return;
  ul.innerHTML = '';
  const org = SNAPSHOT?.catalog?.[selectedOrg];
  if (!org?.children) return;
  org.children.forEach((cat, idx) => {
    const li = document.createElement('li');
    li.className = 'card';
    li.innerHTML = `<div class="label">${cat.name}</div><div class="desc">${cat.description || ''}</div>`;
    li.addEventListener('click', () => {
      selectedCat = idx;
      if (catTitle()) catTitle().textContent = cat.name;
      renderOutfits();
    });
    ul.appendChild(li);
  });
}

function renderOutfits() {
  const grid = outfitGrid(); if (!grid) return;
  grid.innerHTML = '';
  const q = (searchBox()?.value || '').toLowerCase();
  const org = SNAPSHOT?.catalog?.[selectedOrg];
  const cat = org?.children?.[selectedCat];
  if (!cat?.outfits) return;

  cat.outfits.forEach((o, idxOrig) => {
    if (q && !(o.label || '').toLowerCase().includes(q)) return;
    const li = document.createElement('li');
    li.className = 'card';
    li.innerHTML = `
      ${o.thumb ? `<img src="${o.thumb}" alt="" style="width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:6px;opacity:.95;" />` : ''}
      <div class="label">${o.label || 'Outfit'}</div>
    `;
    li.addEventListener('click', () => {
      post('applyOutfit', {
        orgIdx: selectedOrg,
        catIdx: selectedCat,
        outfitIdx: idxOrig,
        orgName: org?.org || '',
        catName: cat?.name || '',
        outfitLabel: o?.label || ''
      });
    });
    grid.appendChild(li);
  });
}

window.addEventListener('message', (e) => {
  const { action, payload } = e.data || {};
  if (action === 'open') {
    SNAPSHOT = payload || {};
    const el = root(); if (el) el.classList.remove('hidden');
    selectedOrg = -1; selectedCat = -1;
    if (orgTitle()) orgTitle().textContent = 'Select an organisation';
    if (catTitle()) catTitle().textContent = 'Select a category';
    if (searchBox()) searchBox().value = '';
    renderOrgs();
    if (orgList()) orgList().scrollTop = 0;
    if (catList()) catList().scrollTop = 0;
    if (outfitGrid()) outfitGrid().scrollTop = 0;
  }
  if (action === 'close') nukeUI();
});

// Close button & ESC
document.getElementById('btn-close')?.addEventListener('click', () => post('close'));
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') post('close'); });
searchBox()?.addEventListener('input', renderOutfits);
document.addEventListener('DOMContentLoaded', nukeUI);
