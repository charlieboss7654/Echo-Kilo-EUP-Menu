Config = {}

Config.AutoSwitchToBaseModel = true
Config.BaseModel = `mp_m_freemode_01`

-- SIMPLE, FRIENDLY CONFIG:
-- number => drawable with texture 0
-- {drawable, texture} => both values
-- PROPS: use -1 to clear (remove hat/glasses etc.)
-- Components: mask, hair, arms, pants, bag, shoes, accessory, undershirt, kevlar, decals, torso
-- Props:      hat, glasses, ear, watch, bracelet

Config.Catalog = {
  {
    org = "New Hartshire Constabulary",
    children = {
      {
        name = "Frontline Policing",
        description = "FLPD divisions and standard patrol kits.",
        outfits = {
          {
            label = "Patrol",
            components = { torso=55, undershirt=15, pants=35, shoes=25, kevlar=10, arms=0, decals=0 },
            props      = { hat=12, glasses=-1 }
          },
          {
            label = "Traffic (Hi-Vis)",
            components = { torso=56, undershirt=15, pants=35, shoes=25, kevlar=20, arms=0 },
            props      = { hat=25 }
          }
        }
      },
      {
        name = "CID",
        description = "Detective branch formal/casual options.",
        outfits = {
          {
            label = "CID Suit",
            components = { torso=25, undershirt=10, pants=10, shoes=5, arms=1, decals=0, kevlar=0 },
            props      = { hat=-1, glasses={5,0} }
          }
        }
      }
    }
  },

  {
    org = "New Hartshire Fire and Rescue",
    children = {
      {
        name = "Operations",
        description = "Firefighting & paramedic attire.",
        outfits = {
          {
            label = "Firefighter Gear",
            components = { torso=60, undershirt=0, pants=50, shoes=20, arms=0 },
            props      = { hat=15 }
          },
          {
            label = "Paramedic",
            components = { torso=20, undershirt=5, pants=30, shoes=10, arms=2 }
          }
        }
      }
    }
  },

  {
    org = "British Transport Police",
    children = {
      {
        name = "Patrol",
        description = "Rail-focused patrol kits.",
        outfits = {
          {
            label = "BTP Patrol",
            components = { torso=70, undershirt=15, pants=35, shoes=25, kevlar=12, arms=0 },
            props      = { hat=45 }
          }
        }
      }
    }
  },

  {
    org = "Civilian",
    children = {
      {
        name = "Smart",
        description = "Business/formal wear.",
        outfits = {
          {
            label = "Business Suit",
            components = { torso=25, undershirt=10, pants=10, shoes=5, arms=1 },
            props      = { hat=-1, glasses=3 }
          }
        }
      }
    }
  }
}
