local uiOpen = false

local ComponentMap = {
  mask=1, hair=2, arms=3, pants=4, bag=5, shoes=6, accessory=7, undershirt=8, kevlar=9, decals=10, torso=11
}
local PropMap = { hat=0, glasses=1, ear=2, watch=6, bracelet=7 }

local function asDrawTex(v)
  if type(v) == 'table' then
    local d = v[1] or v.d or v.drawable or 0
    local t = v[2] or v.t or v.texture  or 0
    return tonumber(d) or 0, tonumber(t) or 0
  end
  return tonumber(v) or 0, 0
end

local function isFreemode(model)
  return model == `mp_m_freemode_01` or model == `mp_f_freemode_01`
end

local function ensureBaseModel()
  if not Config.AutoSwitchToBaseModel then return end
  local ped = PlayerPedId()
  if isFreemode(GetEntityModel(ped)) then return end
  local base = Config.BaseModel or `mp_m_freemode_01`
  if not IsModelInCdimage(base) or not IsModelValid(base) then
    print('[EUP UI] WARNING: BaseModel invalid; skipping model switch.')
    return
  end
  RequestModel(base)
  while not HasModelLoaded(base) do Wait(0) end
  SetPlayerModel(PlayerId(), base)
  SetModelAsNoLongerNeeded(base)
  ped = PlayerPedId()
  SetPedDefaultComponentVariation(ped)
  Wait(50)
end

local function refreshPedVariation(ped)
  if Citizen and Citizen.InvokeNative then
    pcall(function()
      Citizen.InvokeNative(0xAAB0FE202E9FC9F0, ped, true)
    end)
  end
  local comp = 3 -- arms is safe to touch
  local d = GetPedDrawableVariation(ped, comp)
  local t = GetPedTextureVariation(ped, comp)
  SetPedComponentVariation(ped, comp, d, t, 0)
end

local function safeSetComponent(ped, compId, drawable, texture)
  local maxDraw = GetNumberOfPedDrawableVariations(ped, compId)
  if maxDraw and maxDraw > 0 and drawable >= maxDraw then
    drawable = math.max(0, maxDraw - 1)
  end
  local maxTex = GetNumberOfPedTextureVariations(ped, compId, drawable)
  if maxTex and maxTex > 0 and texture >= maxTex then
    texture = math.max(0, maxTex - 1)
  end
  SetPedComponentVariation(ped, compId, drawable, texture, 0)
end

local function safeSetProp(ped, propId, drawable, texture)
  if drawable == -1 then ClearPedProp(ped, propId) return end
  local maxDraw = GetNumberOfPedPropDrawableVariations(ped, propId)
  if maxDraw and maxDraw > 0 and drawable >= maxDraw then
    drawable = math.max(0, maxDraw - 1)
  end
  local maxTex = GetNumberOfPedPropTextureVariations(ped, propId, drawable)
  if maxTex and maxTex > 0 and texture >= maxTex then
    texture = math.max(0, maxTex - 1)
  end
  SetPedPropIndex(ped, propId, drawable, texture, true)
end

local function applyOutfit(data)
  if not data then return end
  ensureBaseModel()

  local ped = PlayerPedId()

  local order = { 'torso','arms','undershirt','kevlar','decals','pants','shoes','mask','hair','bag','accessory' }
  if data.components then
    local staged = {}
    for _,k in ipairs(order) do if data.components[k] then staged[#staged+1] = k end end
    for name,_ in pairs(data.components) do
      local known=false; for _,k in ipairs(order) do if k==name then known=true break end end
      if not known then staged[#staged+1] = name end
    end
    for _, name in ipairs(staged) do
      local compId = ComponentMap[name]
      if compId then
        local d,t = asDrawTex(data.components[name])
        safeSetComponent(ped, compId, d, t)
      else
        print(('[EUP UI] Unknown component: %s'):format(tostring(name)))
      end
    end
  end

  ClearAllPedProps(ped)
  if data.props then
    for name, val in pairs(data.props) do
      local propId = PropMap[name]
      if propId then
        local d,t = asDrawTex(val)
        safeSetProp(ped, propId, d, t)
      else
        print(('[EUP UI] Unknown prop: %s'):format(tostring(name)))
      end
    end
  end

  refreshPedVariation(ped)
end

CreateThread(function()
  SetNuiFocus(false, false)
  SendNUIMessage({ action = 'close' })
end)

AddEventHandler('onResourceStop', function(res)
  if res == GetCurrentResourceName() then
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
  end
end)

local function openUI(snapshot)
  if uiOpen then return end
  uiOpen = true
  SetNuiFocus(true, true)
  SendNUIMessage({ action = 'open', payload = snapshot })
end

local function closeUI()
  SetNuiFocus(false, false)
  SendNUIMessage({ action = 'close' })
  uiOpen = false
end

local function buildSnapshot()
  return { catalog = Config.Catalog }
end

RegisterCommand('eup', function()
  openUI(buildSnapshot())
end, false)

RegisterCommand('eupclose', function() closeUI() end, false)

RegisterNUICallback('close', function(_, cb) closeUI(); cb('ok') end)

RegisterNUICallback('applyOutfit', function(data, cb)
  local org   = Config.Catalog[data.orgIdx]
  local cat   = org and org.children and org.children[data.catIdx]
  local outfit= cat and cat.outfits and cat.outfits[data.outfitIdx]

  if not org and data.orgName then
    for _,o in ipairs(Config.Catalog) do
      if o.org == data.orgName then org = o break end
    end
  end
  if not cat and org and data.catName then
    for _,c in ipairs(org.children or {}) do
      if c.name == data.catName then cat = c break end
    end
  end
  if not outfit and cat and data.outfitLabel then
    for _,o in ipairs(cat.outfits or {}) do
      if o.label == data.outfitLabel then outfit = o break end
    end
  end

  if outfit then
    applyOutfit(outfit)
  else
    print('[EUP UI] Invalid selection (org/category/outfit not found).')
  end
  cb('ok')
end)
